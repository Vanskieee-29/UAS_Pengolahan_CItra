from gui import ImageProcessingApp

app = ImageProcessingApp()
app.mainloop()