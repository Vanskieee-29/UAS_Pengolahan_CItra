import tkinter as tk
from tkinter import ttk
from tkinter import filedialog, messagebox

import cv2
import numpy as np

from PIL import Image, ImageTk

from preprocessing import *
from enhancement import *
from filtering import *
from edge_detection import *
from segmentation import *
from face_detection import *

from style import *


class ImageProcessingApp(tk.Tk):

    def __init__(self):

        super().__init__()

        self.title("Digital Image Processing")
        self.geometry("1380x900")
        self.configure(bg=BG_COLOR)
        self.resizable(False, False)

        set_style()

        # =============================
        # IMAGE VARIABLE
        # =============================

        self.image_path = None

        self.cv_image = None

        self.original_image = None

        self.result_image = None

        self.face_count = 0

        # =============================
        # GUI
        # =============================

        self.create_widgets()

    def create_widgets(self):

        ###################################################
        ## HEADER
        ###################################################

        header = ttk.Label(
            self,
            text="DIGITAL IMAGE PROCESSING APPLICATION\nCelebrity Face Dataset using Python & OpenCV",
            style="Header.TLabel",
            anchor="center"
        )

        header.pack(fill="x")

        ###################################################
        ## TOP BUTTON
        ###################################################

        top_frame = tk.Frame(
            self,
            bg=BG_COLOR
        )

        top_frame.pack(pady=10)

        self.btn_upload = ttk.Button(
            top_frame,
            text="Upload Image",
            command=self.load_image
        )

        self.btn_upload.grid(
            row=0,
            column=0,
            padx=5
        )

        self.btn_save = ttk.Button(
            top_frame,
            text="Save Result",
            command=self.save_image,
            state="disabled"
        )

        self.btn_save.grid(
            row=0,
            column=1,
            padx=5
        )

        ###################################################
        ## IMAGE FRAME
        ###################################################

        image_frame = tk.Frame(
            self,
            bg=BG_COLOR
        )

        image_frame.pack()

        left_frame = ttk.LabelFrame(
            image_frame,
            text="Original Image",
            style="Section.TLabelframe"
        )

        left_frame.grid(
            row=0,
            column=0,
            padx=15
        )

        right_frame = ttk.LabelFrame(
            image_frame,
            text="Processed Image",
            style="Section.TLabelframe"
        )

        right_frame.grid(
            row=0,
            column=1,
            padx=15
        )

        self.original_canvas = tk.Canvas(
            left_frame,
            width=450,
            height=450,
            bg="white"
        )

        self.original_canvas.pack()

        self.process_canvas = tk.Canvas(
            right_frame,
            width=450,
            height=450,
            bg="white"
        )

        self.process_canvas.pack()

        ###################################################
        ## INFORMATION
        ###################################################

        info_frame = ttk.LabelFrame(
            self,
            text="Processing Information",
            style="Section.TLabelframe"
        )

        info_frame.pack(
            fill="x",
            padx=20,
            pady=10
        )

        self.info = tk.Label(
            info_frame,
            justify="left",
            anchor="w",
            bg="white",
            font=("Segoe UI",10),
            height=6
        )

        self.info.pack(
            fill="x",
            padx=10,
            pady=10
        )

        self.info.config(
            text="""
            Method :
            Resolution :
            Channels :
            Faces :
            Status :
            """
                    )

        ###################################################
        ## BUTTON FRAME
        ###################################################

        process_frame = ttk.LabelFrame(
            self,
            text="Image Processing",
            style="Section.TLabelframe"
        )

        process_frame.pack(
            fill="x",
            padx=20,
            pady=10
        )

        self.buttons = {}

        button_data = [

            ("Grayscale", self.grayscale),
            ("Binary", self.binary),

            ("Histogram", self.histogram),
            ("Contrast", self.contrast),
            ("Brightness", self.brightness),

            ("Mean", self.mean),
            ("Median", self.median),
            ("Gaussian", self.gaussian),

            ("Sobel", self.sobel),
            ("Canny", self.canny),

            ("Threshold", self.threshold),
            ("K-Means", self.kmeans),

            ("Face Detection", self.face_detection)

        ]

        row = 0
        col = 0

        for text, command in button_data:

            btn = ttk.Button(
                process_frame,
                text=text,
                width=18,
                command=command,
                state="disabled"
            )

            btn.grid(
                row=row,
                column=col,
                padx=6,
                pady=6
            )

            self.buttons[text] = btn

            col += 1

            if col == 4:
                row += 1
                col = 0

        ###################################################
        ## STATUS BAR
        ###################################################

        self.status = tk.Label(
            self,
            text="Status : Ready",
            bg=HEADER,
            fg="white",
            anchor="w",
            padx=10
        )

        self.status.pack(
            fill="x",
            side="bottom"
        )

    # ==========================================================
    # LOAD IMAGE
    # ==========================================================

    def load_image(self):

        path = filedialog.askopenfilename(
            filetypes=[
                ("Image Files", "*.jpg *.jpeg *.png")
            ]
        )

        if not path:
            return

        self.image_path = path

        image = cv2.imread(path)

        image = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2RGB
        )

        self.cv_image = image.copy()
        self.result_image = image.copy()

        self.show_original_image(image)
        self.show_processed_image(image)

        self.enable_buttons()

        h, w = image.shape[:2]

        self.update_information(
            method="Original Image",
            resolution=f"{w} x {h}",
            channels=3,
            faces="-",
            status="Image Loaded Successfully"
        )

        self.status.config(
            text="Status : Image Loaded Successfully"
        )
        
    # ==========================================================
    # SHOW ORIGINAL IMAGE
    # ==========================================================

    def show_original_image(self, image):

        img = Image.fromarray(image)

        img.thumbnail((430, 430))

        photo = ImageTk.PhotoImage(img)

        self.original_canvas.delete("all")

        self.original_canvas.create_image(
            225,
            225,
            image=photo
        )

        self.original_canvas.image = photo
        
    # ==========================================================
    # SHOW RESULT IMAGE
    # ==========================================================

    def show_processed_image(self, image):

        if len(image.shape) == 2:

            img = Image.fromarray(image)

        else:

            img = Image.fromarray(image.astype(np.uint8))

        img.thumbnail((430,430))

        photo = ImageTk.PhotoImage(img)

        self.process_canvas.delete("all")

        self.process_canvas.create_image(
            225,
            225,
            image=photo
        )

        self.process_canvas.image = photo
        
    # ==========================================================
    # ENABLE BUTTON
    # ==========================================================

    def enable_buttons(self):

        for btn in self.buttons.values():

            btn.config(state="normal")

        self.btn_save.config(state="normal")
        
    # ==========================================================
    # UPDATE INFORMATION
    # ==========================================================

    def update_information(
            self,
            method,
            resolution,
            channels,
            faces,
            status
    ):

        self.info.config(

            text=f"""
    Method      : {method}

    Resolution : {resolution}

    Channels   : {channels}

    Faces      : {faces}

    Status     : {status}
    """

        )
        
    # ==========================================================
    # SAVE IMAGE
    # ==========================================================

    def save_image(self):

        if self.result_image is None:

            messagebox.showwarning(
                "Warning",
                "Tidak ada hasil yang dapat disimpan."
            )

            return

        filename = filedialog.asksaveasfilename(

            defaultextension=".png",

            filetypes=[
                ("PNG", "*.png"),
                ("JPEG", "*.jpg")
            ]

        )

        if not filename:
            return

        image = self.result_image

        if len(image.shape) == 3:

            image = cv2.cvtColor(
                image,
                cv2.COLOR_RGB2BGR
            )

        cv2.imwrite(
            filename,
            image
        )

        messagebox.showinfo(
            "Success",
            "Image saved successfully."
        )